import os
while True:
    os.system('eject')
    os.system('eject - t')