DROP TABLE IF EXISTS user;


CREATE TABLE user (
  id_user INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL

);


CREATE TABLE cobra_score (
  id_score INTEGER PRIMARY KEY AUTOINCREMENT,
  id_user INTEGER,
  score text,
  FOREIGN KEY (id_user) REFERENCES user(id_user)
);


CREATE TABLE pong_score (
  id_score INTEGER PRIMARY KEY AUTOINCREMENT,
  id_user INTEGER,
  score text,
  FOREIGN KEY (id_user) REFERENCES user(id_user)
);


CREATE TABLE asteroids_score (
  id_score INTEGER PRIMARY KEY AUTOINCREMENT,
  id_user INTEGER,
  score text,
  FOREIGN KEY (id_user) REFERENCES user(id_user)
);


CREATE TABLE space_score (
  id_score INTEGER PRIMARY KEY AUTOINCREMENT,
  id_user INTEGER,
  score text,
  FOREIGN KEY (id_user) REFERENCES user(id_user)
);


CREATE TABLE brick_score (
  id_score INTEGER PRIMARY KEY AUTOINCREMENT,
  id_user INTEGER,
  score text,
  FOREIGN KEY (id_user) REFERENCES user(id_user)
);



