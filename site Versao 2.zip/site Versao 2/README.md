# Projeto-Site-de-jogos



## Linguagens usadas:

## site:
    - html
    - css
    - javasript
    - sql
    - Python
    - Flask para o login

## jogos:

    - Javascript


## Objetivo:

    Construir um site que hospede jogos antigos e disputar pontuações contra outros usuarios
